PSP_Drone v0.5 por DS_Marine
ES
Controles
Pad digital: Voltereta en la direccion de la flecha pulsada (solo en drones V2)
Joystick analogico: Movimiento horizontal (strafe) y avance/retroceso
/\ Aumentar altura
X Disminuir altura
O Despegar
[] Aterrizar
L Rotacion antihoraria
R Rotacion horaria
START: Menu
El dron se puede comandar desde el menu, pero los botones [], O y el PAD cambian de funcion.

EN
Controls
D.Pad: Perform a flip, drirection according to the arrow used (V2 drones only)
Analog: Strafe and move forward/backward
/\ climb
X descent
O Take off
[] Landing
L CCW Rotate
R CW Rotate
START: Menu
Drone can still be controlled within menu screen, but [], O and D.PAD has other functions.

Known bugs:
It might take many key presses for the drone to take off.
